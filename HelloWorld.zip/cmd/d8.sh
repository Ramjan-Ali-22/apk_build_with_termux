#!/bin/bash
cd ..
d8 --lib "sdk/platforms/android-29/android.jar" --min-api 29 --output build/ src/MainActivity.class