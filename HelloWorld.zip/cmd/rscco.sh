#!/bin/bash
cd ..
aapt2 compile -o build/compiled.zip src/res/values/strings.xml