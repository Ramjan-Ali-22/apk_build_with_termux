#!/bin/bash
cd ..
aapt2 compile -o build/compiled.zip build/res/values/strings.xml