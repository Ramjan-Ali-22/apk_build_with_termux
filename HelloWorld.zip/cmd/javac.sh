#!/bin/bash
cd ..
javac -source 21 -target 21 -classpath "sdk/platforms/android-29/android.jar" src/MainActivity.java
mv src/MainActivity.class build/