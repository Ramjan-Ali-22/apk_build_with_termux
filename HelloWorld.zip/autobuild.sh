#!/bin/bash
cd cmd/

chmod +x javac.sh d8.sh rscco.sh rscapk.sh dexadd.sh apkalign.sh signapk.sh

./javac.sh
./d8.sh
./rscco.sh
./rscapk.sh
./dexadd.sh
./apkalign.sh
./signapk.sh

echo apk build successfuls 😎😎😎