#!/bin/bash
cd cmd/

./javac.sh
./d8.sh
./aapt2.sh
./dexadd.sh
./apkalign.sh
./signapk.sh

echo apk build successfuls 😎😎😎