#!/bin/bash
cd ..
aapt2 link -I "sdk/platforms/android-29/android.jar" --manifest AndroidManifest.xml --min-sdk-version 29 --target-sdk-version 29 -o build/unsigned.apk